<?php
    //Redireccionar al Login

    header('Location:vistas/login.html');
?>