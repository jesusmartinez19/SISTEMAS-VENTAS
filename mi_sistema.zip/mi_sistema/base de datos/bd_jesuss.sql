-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema bd_jesus
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bd_jesus
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bd_jesus` DEFAULT CHARACTER SET latin1 ;
-- -----------------------------------------------------
-- Schema bd_jesuss
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema bd_jesuss
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `bd_jesuss` DEFAULT CHARACTER SET latin1 ;
USE `bd_jesus` ;

-- -----------------------------------------------------
-- Table `bd_jesus`.`categoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`categoria` (
  `idcategoria` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `descripcion` VARCHAR(256) NULL DEFAULT NULL,
  `condicion` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idcategoria`),
  UNIQUE INDEX `nombre_UNIQUE` (`nombre` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`articulo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`articulo` (
  `idarticulo` INT(11) NOT NULL AUTO_INCREMENT,
  `idcategoria` INT(11) NOT NULL,
  `codigo` VARCHAR(50) NULL DEFAULT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  `stock` INT(11) NOT NULL,
  `descripcion` VARCHAR(256) NULL DEFAULT NULL,
  `imagen` VARCHAR(50) NULL DEFAULT NULL,
  `condicion` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idarticulo`),
  UNIQUE INDEX `nombre_UNIQUE` (`nombre` ASC) VISIBLE,
  INDEX `fk_articulo_categoria_idx` (`idcategoria` ASC) VISIBLE,
  CONSTRAINT `fk_articulo_categoria`
    FOREIGN KEY (`idcategoria`)
    REFERENCES `bd_jesus`.`categoria` (`idcategoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`persona`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`persona` (
  `idpersona` INT(11) NOT NULL AUTO_INCREMENT,
  `tipo_persona` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  `tipo_documento` VARCHAR(20) NULL DEFAULT NULL,
  `num_documento` VARCHAR(20) NULL DEFAULT NULL,
  `direccion` VARCHAR(70) NULL DEFAULT NULL,
  `telefono` VARCHAR(9) NULL DEFAULT NULL,
  `email` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`idpersona`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`usuario` (
  `idusuario` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `tipo_documento` VARCHAR(20) NOT NULL,
  `num_documento` VARCHAR(20) NOT NULL,
  `direccion` VARCHAR(70) NOT NULL,
  `telefono` VARCHAR(20) NULL DEFAULT NULL,
  `email` VARCHAR(50) NULL DEFAULT NULL,
  `cargo` VARCHAR(20) NULL DEFAULT NULL,
  `login` VARCHAR(20) NOT NULL,
  `clave` VARCHAR(64) NOT NULL,
  `imagen` VARCHAR(50) NOT NULL,
  `condicion` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`ingreso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`ingreso` (
  `idingreso` INT(11) NOT NULL AUTO_INCREMENT,
  `idproveedor` INT(11) NOT NULL,
  `idusuario` INT(11) NOT NULL,
  `tipo_comprobante` VARCHAR(20) NOT NULL,
  `serie_comprobante` VARCHAR(7) NULL DEFAULT NULL,
  `num_comprobante` VARCHAR(10) NOT NULL,
  `fecha_hora` DATETIME NOT NULL,
  `impuesto` DECIMAL(4,2) NOT NULL,
  `total_compra` DECIMAL(11,2) NOT NULL,
  `estado` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idingreso`),
  INDEX `fk_ingreso_persona_idx` (`idproveedor` ASC) VISIBLE,
  INDEX `fk_ingreso_usuario_idx` (`idusuario` ASC) VISIBLE,
  CONSTRAINT `fk_ingreso_persona`
    FOREIGN KEY (`idproveedor`)
    REFERENCES `bd_jesus`.`persona` (`idpersona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ingreso_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_jesus`.`usuario` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`detalle_ingreso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`detalle_ingreso` (
  `iddetalle_ingreso` INT(11) NOT NULL AUTO_INCREMENT,
  `idingreso` INT(11) NOT NULL,
  `idarticulo` INT(11) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precio_compra` DECIMAL(11,2) NOT NULL,
  `precio_venta` DECIMAL(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_ingreso`),
  INDEX `fk_detalle_ingreso_ingreso_idx` (`idingreso` ASC) VISIBLE,
  INDEX `fk_detalle_ingreso_articulo_idx` (`idarticulo` ASC) VISIBLE,
  CONSTRAINT `fk_detalle_ingreso_articulo`
    FOREIGN KEY (`idarticulo`)
    REFERENCES `bd_jesus`.`articulo` (`idarticulo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_ingreso_ingreso`
    FOREIGN KEY (`idingreso`)
    REFERENCES `bd_jesus`.`ingreso` (`idingreso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`venta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`venta` (
  `idventa` INT(11) NOT NULL AUTO_INCREMENT,
  `idcliente` INT(11) NOT NULL,
  `idusuario` INT(11) NOT NULL,
  `tipo_comprobante` VARCHAR(20) NOT NULL,
  `serie_comprobante` VARCHAR(7) NULL DEFAULT NULL,
  `num_comprobante` VARCHAR(10) NOT NULL,
  `fecha_hora` DATETIME NOT NULL,
  `impuesto` DECIMAL(4,2) NOT NULL,
  `total_venta` DECIMAL(11,2) NOT NULL,
  `estado` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idventa`),
  INDEX `fk_venta_persona_idx` (`idcliente` ASC) VISIBLE,
  INDEX `fk_venta_usuario_idx` (`idusuario` ASC) VISIBLE,
  CONSTRAINT `fk_venta_persona`
    FOREIGN KEY (`idcliente`)
    REFERENCES `bd_jesus`.`persona` (`idpersona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_venta_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_jesus`.`usuario` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`detalle_venta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`detalle_venta` (
  `iddetalle_venta` INT(11) NOT NULL AUTO_INCREMENT,
  `idventa` INT(11) NOT NULL,
  `idarticulo` INT(11) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precio_venta` DECIMAL(11,2) NOT NULL,
  `descuento` DECIMAL(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_venta`),
  INDEX `fk_detalle_venta_venta_idx` (`idventa` ASC) VISIBLE,
  INDEX `fk_detalle_venta_articulo_idx` (`idarticulo` ASC) VISIBLE,
  CONSTRAINT `fk_detalle_venta_articulo`
    FOREIGN KEY (`idarticulo`)
    REFERENCES `bd_jesus`.`articulo` (`idarticulo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_venta_venta`
    FOREIGN KEY (`idventa`)
    REFERENCES `bd_jesus`.`venta` (`idventa`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`permiso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`permiso` (
  `idpermiso` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`idpermiso`))
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesus`.`usuario_permiso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesus`.`usuario_permiso` (
  `idpermiso_usuario` INT(11) NOT NULL AUTO_INCREMENT,
  `idusuario` INT(11) NOT NULL,
  `idpermiso` INT(11) NOT NULL,
  PRIMARY KEY (`idpermiso_usuario`),
  INDEX `fk_usuario_permiso_usuario_idx` (`idusuario` ASC) VISIBLE,
  INDEX `fk_usuario_permiso_permiso_idx` (`idpermiso` ASC) VISIBLE,
  CONSTRAINT `fk_usuario_permiso_permiso`
    FOREIGN KEY (`idpermiso`)
    REFERENCES `bd_jesus`.`permiso` (`idpermiso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_permiso_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_jesus`.`usuario` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8;

USE `bd_jesuss` ;

-- -----------------------------------------------------
-- Table `bd_jesuss`.`categoria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`categoria` (
  `idcategoria` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(50) NOT NULL,
  `descripcion` VARCHAR(256) NULL DEFAULT NULL,
  `condicion` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idcategoria`),
  UNIQUE INDEX `nombre_UNIQUE` (`nombre` ASC) VISIBLE)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`articulo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`articulo` (
  `idarticulo` INT(11) NOT NULL AUTO_INCREMENT,
  `idcategoria` INT(11) NOT NULL,
  `codigo` VARCHAR(50) NULL DEFAULT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  `stock` INT(11) NOT NULL,
  `descripcion` VARCHAR(256) NULL DEFAULT NULL,
  `imagen` VARCHAR(50) NULL DEFAULT NULL,
  `condicion` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idarticulo`),
  UNIQUE INDEX `nombre_UNIQUE` (`nombre` ASC) VISIBLE,
  INDEX `fk_articulo_categoria_idx` (`idcategoria` ASC) VISIBLE,
  CONSTRAINT `fk_articulo_categoria`
    FOREIGN KEY (`idcategoria`)
    REFERENCES `bd_jesuss`.`categoria` (`idcategoria`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`persona`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`persona` (
  `idpersona` INT(11) NOT NULL AUTO_INCREMENT,
  `tipo_persona` VARCHAR(20) NOT NULL,
  `nombre` VARCHAR(100) NOT NULL,
  `tipo_documento` VARCHAR(20) NULL DEFAULT NULL,
  `num_documento` VARCHAR(20) NULL DEFAULT NULL,
  `direccion` VARCHAR(70) NULL DEFAULT NULL,
  `telefono` VARCHAR(9) NULL DEFAULT NULL,
  `email` VARCHAR(50) NULL DEFAULT NULL,
  PRIMARY KEY (`idpersona`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`usuario` (
  `idusuario` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(100) NOT NULL,
  `tipo_documento` VARCHAR(20) NOT NULL,
  `num_documento` VARCHAR(20) NOT NULL,
  `direccion` VARCHAR(70) NOT NULL,
  `telefono` VARCHAR(20) NULL DEFAULT NULL,
  `email` VARCHAR(50) NULL DEFAULT NULL,
  `cargo` VARCHAR(20) NULL DEFAULT NULL,
  `login` VARCHAR(20) NOT NULL,
  `clave` VARCHAR(64) NOT NULL,
  `imagen` VARCHAR(50) NOT NULL,
  `condicion` TINYINT(4) NOT NULL DEFAULT '1',
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB
AUTO_INCREMENT = 5
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`ingreso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`ingreso` (
  `idingreso` INT(11) NOT NULL AUTO_INCREMENT,
  `idproveedor` INT(11) NOT NULL,
  `idusuario` INT(11) NOT NULL,
  `tipo_comprobante` VARCHAR(20) NOT NULL,
  `serie_comprobante` VARCHAR(7) NULL DEFAULT NULL,
  `num_comprobante` VARCHAR(10) NOT NULL,
  `fecha_hora` DATETIME NOT NULL,
  `impuesto` DECIMAL(4,2) NOT NULL,
  `total_compra` DECIMAL(11,2) NOT NULL,
  `estado` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idingreso`),
  INDEX `fk_ingreso_persona_idx` (`idproveedor` ASC) VISIBLE,
  INDEX `fk_ingreso_usuario_idx` (`idusuario` ASC) VISIBLE,
  CONSTRAINT `fk_ingreso_persona`
    FOREIGN KEY (`idproveedor`)
    REFERENCES `bd_jesuss`.`persona` (`idpersona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_ingreso_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_jesuss`.`usuario` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`detalle_ingreso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`detalle_ingreso` (
  `iddetalle_ingreso` INT(11) NOT NULL AUTO_INCREMENT,
  `idingreso` INT(11) NOT NULL,
  `idarticulo` INT(11) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precio_compra` DECIMAL(11,2) NOT NULL,
  `precio_venta` DECIMAL(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_ingreso`),
  INDEX `fk_detalle_ingreso_ingreso_idx` (`idingreso` ASC) VISIBLE,
  INDEX `fk_detalle_ingreso_articulo_idx` (`idarticulo` ASC) VISIBLE,
  CONSTRAINT `fk_detalle_ingreso_articulo`
    FOREIGN KEY (`idarticulo`)
    REFERENCES `bd_jesuss`.`articulo` (`idarticulo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_ingreso_ingreso`
    FOREIGN KEY (`idingreso`)
    REFERENCES `bd_jesuss`.`ingreso` (`idingreso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`venta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`venta` (
  `idventa` INT(11) NOT NULL AUTO_INCREMENT,
  `idcliente` INT(11) NOT NULL,
  `idusuario` INT(11) NOT NULL,
  `tipo_comprobante` VARCHAR(20) NOT NULL,
  `serie_comprobante` VARCHAR(7) NULL DEFAULT NULL,
  `num_comprobante` VARCHAR(10) NOT NULL,
  `fecha_hora` DATETIME NOT NULL,
  `impuesto` DECIMAL(4,2) NOT NULL,
  `total_venta` DECIMAL(11,2) NOT NULL,
  `estado` VARCHAR(20) NOT NULL,
  PRIMARY KEY (`idventa`),
  INDEX `fk_venta_persona_idx` (`idcliente` ASC) VISIBLE,
  INDEX `fk_venta_usuario_idx` (`idusuario` ASC) VISIBLE,
  CONSTRAINT `fk_venta_persona`
    FOREIGN KEY (`idcliente`)
    REFERENCES `bd_jesuss`.`persona` (`idpersona`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_venta_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_jesuss`.`usuario` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`detalle_venta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`detalle_venta` (
  `iddetalle_venta` INT(11) NOT NULL AUTO_INCREMENT,
  `idventa` INT(11) NOT NULL,
  `idarticulo` INT(11) NOT NULL,
  `cantidad` INT(11) NOT NULL,
  `precio_venta` DECIMAL(11,2) NOT NULL,
  `descuento` DECIMAL(11,2) NOT NULL,
  PRIMARY KEY (`iddetalle_venta`),
  INDEX `fk_detalle_venta_venta_idx` (`idventa` ASC) VISIBLE,
  INDEX `fk_detalle_venta_articulo_idx` (`idarticulo` ASC) VISIBLE,
  CONSTRAINT `fk_detalle_venta_articulo`
    FOREIGN KEY (`idarticulo`)
    REFERENCES `bd_jesuss`.`articulo` (`idarticulo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_detalle_venta_venta`
    FOREIGN KEY (`idventa`)
    REFERENCES `bd_jesuss`.`venta` (`idventa`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 2
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`permiso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`permiso` (
  `idpermiso` INT(11) NOT NULL AUTO_INCREMENT,
  `nombre` VARCHAR(30) NOT NULL,
  PRIMARY KEY (`idpermiso`))
ENGINE = InnoDB
AUTO_INCREMENT = 8
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `bd_jesuss`.`usuario_permiso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `bd_jesuss`.`usuario_permiso` (
  `idpermiso_usuario` INT(11) NOT NULL AUTO_INCREMENT,
  `idusuario` INT(11) NOT NULL,
  `idpermiso` INT(11) NOT NULL,
  PRIMARY KEY (`idpermiso_usuario`),
  INDEX `fk_usuario_permiso_usuario_idx` (`idusuario` ASC) VISIBLE,
  INDEX `fk_usuario_permiso_permiso_idx` (`idpermiso` ASC) VISIBLE,
  CONSTRAINT `fk_usuario_permiso_permiso`
    FOREIGN KEY (`idpermiso`)
    REFERENCES `bd_jesuss`.`permiso` (`idpermiso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_usuario_permiso_usuario`
    FOREIGN KEY (`idusuario`)
    REFERENCES `bd_jesuss`.`usuario` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 15
DEFAULT CHARACTER SET = utf8;

USE `bd_jesus`;

DELIMITER $$
USE `bd_jesus`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `bd_jesus`.`tr_updStockIngresoAnular`
AFTER UPDATE ON `bd_jesus`.`ingreso`
FOR EACH ROW
BEGIN
    UPDATE articulo a
    JOIN detalle_ingreso di
    ON di.idarticulo = a.idarticulo
    AND di.idingreso = new.idingreso
    SET a.stock = a.stock - di.cantidad;
END$$

USE `bd_jesus`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `bd_jesus`.`tr_updStockIngreso`
AFTER INSERT ON `bd_jesus`.`detalle_ingreso`
FOR EACH ROW
BEGIN UPDATE articulo SET stock = stock + NEW.cantidad 
WHERE articulo.idarticulo = NEW.idarticulo;
END$$

USE `bd_jesus`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `bd_jesus`.`tr_updStockVenta`
AFTER INSERT ON `bd_jesus`.`detalle_venta`
FOR EACH ROW
BEGIN
UPDATE articulo SET stock = stock - NEW.cantidad
WHERE articulo.idarticulo = NEW.idarticulo;
END$$


DELIMITER ;
USE `bd_jesuss`;

DELIMITER $$
USE `bd_jesuss`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `bd_jesuss`.`tr_updStockIngresoAnular`
AFTER UPDATE ON `bd_jesuss`.`ingreso`
FOR EACH ROW
BEGIN
    UPDATE articulo a
    JOIN detalle_ingreso di
    ON di.idarticulo = a.idarticulo
    AND di.idingreso = new.idingreso
    SET a.stock = a.stock - di.cantidad;
END$$

USE `bd_jesuss`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `bd_jesuss`.`tr_updStockIngreso`
AFTER INSERT ON `bd_jesuss`.`detalle_ingreso`
FOR EACH ROW
BEGIN UPDATE articulo SET stock = stock + NEW.cantidad 
WHERE articulo.idarticulo = NEW.idarticulo;
END$$

USE `bd_jesuss`$$
CREATE
DEFINER=`root`@`localhost`
TRIGGER `bd_jesuss`.`tr_updStockVenta`
AFTER INSERT ON `bd_jesuss`.`detalle_venta`
FOR EACH ROW
BEGIN
UPDATE articulo SET stock = stock - NEW.cantidad
WHERE articulo.idarticulo = NEW.idarticulo;
END$$


DELIMITER ;

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
